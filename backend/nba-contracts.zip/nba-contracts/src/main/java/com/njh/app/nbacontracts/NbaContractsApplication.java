package com.njh.app.nbacontracts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NbaContractsApplication {

	public static void main(String[] args) {
		SpringApplication.run(NbaContractsApplication.class, args);
	}

}
